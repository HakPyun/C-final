﻿namespace Project3
{
    partial class 시작화면
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_p = new System.Windows.Forms.Button();
            this.btn_s = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_p
            // 
            this.btn_p.Location = new System.Drawing.Point(112, 41);
            this.btn_p.Name = "btn_p";
            this.btn_p.Size = new System.Drawing.Size(288, 117);
            this.btn_p.TabIndex = 0;
            this.btn_p.Text = "교수";
            this.btn_p.UseVisualStyleBackColor = true;
            this.btn_p.Click += new System.EventHandler(this.btn_p_Click);
            // 
            // btn_s
            // 
            this.btn_s.Location = new System.Drawing.Point(112, 179);
            this.btn_s.Name = "btn_s";
            this.btn_s.Size = new System.Drawing.Size(288, 117);
            this.btn_s.TabIndex = 0;
            this.btn_s.Text = "학생";
            this.btn_s.UseVisualStyleBackColor = true;
            this.btn_s.Click += new System.EventHandler(this.btn_s_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(112, 322);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(288, 117);
            this.btn_exit.TabIndex = 0;
            this.btn_exit.Text = "종료";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // 시작화면
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 484);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_s);
            this.Controls.Add(this.btn_p);
            this.Name = "시작화면";
            this.Text = "학사관리프로그램 시작화면";
            this.Load += new System.EventHandler(this.시작화면_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_p;
        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.Button btn_exit;
    }
}

