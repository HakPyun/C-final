﻿namespace Project3
{
    partial class 성적입력
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_name1 = new System.Windows.Forms.TextBox();
            this.tb_mid1 = new System.Windows.Forms.TextBox();
            this.tb_final1 = new System.Windows.Forms.TextBox();
            this.tb_attend1 = new System.Windows.Forms.TextBox();
            this.tb_silgi1 = new System.Windows.Forms.TextBox();
            this.tb_hab = new System.Windows.Forms.TextBox();
            this.tb_grade1 = new System.Windows.Forms.TextBox();
            this.tb_name2 = new System.Windows.Forms.TextBox();
            this.tb_mid2 = new System.Windows.Forms.TextBox();
            this.tb_final2 = new System.Windows.Forms.TextBox();
            this.tb_attend2 = new System.Windows.Forms.TextBox();
            this.tb_silgi2 = new System.Windows.Forms.TextBox();
            this.tb_hab2 = new System.Windows.Forms.TextBox();
            this.tb_grade2 = new System.Windows.Forms.TextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(439, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "C# 프로그래밍 응용";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 34);
            this.label2.TabIndex = 1;
            this.label2.Text = "학생명";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(223, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 34);
            this.label3.TabIndex = 2;
            this.label3.Text = "중간";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(385, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 34);
            this.label4.TabIndex = 3;
            this.label4.Text = "기말";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(548, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 34);
            this.label5.TabIndex = 4;
            this.label5.Text = "출석";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(717, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 34);
            this.label6.TabIndex = 5;
            this.label6.Text = "실기";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(879, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 34);
            this.label7.TabIndex = 6;
            this.label7.Text = "합계";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1041, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 34);
            this.label8.TabIndex = 7;
            this.label8.Text = "학점";
            // 
            // tb_name1
            // 
            this.tb_name1.Location = new System.Drawing.Point(40, 140);
            this.tb_name1.Name = "tb_name1";
            this.tb_name1.Size = new System.Drawing.Size(114, 46);
            this.tb_name1.TabIndex = 8;
            // 
            // tb_mid1
            // 
            this.tb_mid1.Location = new System.Drawing.Point(204, 140);
            this.tb_mid1.Name = "tb_mid1";
            this.tb_mid1.Size = new System.Drawing.Size(114, 46);
            this.tb_mid1.TabIndex = 8;
            // 
            // tb_final1
            // 
            this.tb_final1.Location = new System.Drawing.Point(368, 140);
            this.tb_final1.Name = "tb_final1";
            this.tb_final1.Size = new System.Drawing.Size(114, 46);
            this.tb_final1.TabIndex = 8;
            this.tb_final1.Click += new System.EventHandler(this.tb_final1_Click);
            this.tb_final1.TextChanged += new System.EventHandler(this.tb_final1_TextChanged);
            // 
            // tb_attend1
            // 
            this.tb_attend1.Location = new System.Drawing.Point(532, 140);
            this.tb_attend1.Name = "tb_attend1";
            this.tb_attend1.Size = new System.Drawing.Size(114, 46);
            this.tb_attend1.TabIndex = 8;
            this.tb_attend1.Click += new System.EventHandler(this.tb_attend1_Click);
            // 
            // tb_silgi1
            // 
            this.tb_silgi1.Location = new System.Drawing.Point(696, 140);
            this.tb_silgi1.Name = "tb_silgi1";
            this.tb_silgi1.Size = new System.Drawing.Size(114, 46);
            this.tb_silgi1.TabIndex = 8;
            this.tb_silgi1.Click += new System.EventHandler(this.tb_silgi1_Click);
            // 
            // tb_hab
            // 
            this.tb_hab.Location = new System.Drawing.Point(860, 140);
            this.tb_hab.Name = "tb_hab";
            this.tb_hab.Size = new System.Drawing.Size(114, 46);
            this.tb_hab.TabIndex = 8;
            this.tb_hab.Click += new System.EventHandler(this.tb_hab_Click);
            this.tb_hab.TextChanged += new System.EventHandler(this.tb_hab_TextChanged);
            // 
            // tb_grade1
            // 
            this.tb_grade1.Location = new System.Drawing.Point(1024, 140);
            this.tb_grade1.Name = "tb_grade1";
            this.tb_grade1.Size = new System.Drawing.Size(114, 46);
            this.tb_grade1.TabIndex = 8;
            // 
            // tb_name2
            // 
            this.tb_name2.Location = new System.Drawing.Point(40, 210);
            this.tb_name2.Name = "tb_name2";
            this.tb_name2.Size = new System.Drawing.Size(114, 46);
            this.tb_name2.TabIndex = 8;
            // 
            // tb_mid2
            // 
            this.tb_mid2.Location = new System.Drawing.Point(204, 210);
            this.tb_mid2.Name = "tb_mid2";
            this.tb_mid2.Size = new System.Drawing.Size(114, 46);
            this.tb_mid2.TabIndex = 8;
            // 
            // tb_final2
            // 
            this.tb_final2.Location = new System.Drawing.Point(368, 210);
            this.tb_final2.Name = "tb_final2";
            this.tb_final2.Size = new System.Drawing.Size(114, 46);
            this.tb_final2.TabIndex = 8;
            // 
            // tb_attend2
            // 
            this.tb_attend2.Location = new System.Drawing.Point(532, 210);
            this.tb_attend2.Name = "tb_attend2";
            this.tb_attend2.Size = new System.Drawing.Size(114, 46);
            this.tb_attend2.TabIndex = 8;
            // 
            // tb_silgi2
            // 
            this.tb_silgi2.Location = new System.Drawing.Point(696, 210);
            this.tb_silgi2.Name = "tb_silgi2";
            this.tb_silgi2.Size = new System.Drawing.Size(114, 46);
            this.tb_silgi2.TabIndex = 8;
            // 
            // tb_hab2
            // 
            this.tb_hab2.Location = new System.Drawing.Point(860, 210);
            this.tb_hab2.Name = "tb_hab2";
            this.tb_hab2.Size = new System.Drawing.Size(114, 46);
            this.tb_hab2.TabIndex = 8;
            this.tb_hab2.Click += new System.EventHandler(this.tb_hab2_Click);
            this.tb_hab2.TextChanged += new System.EventHandler(this.tb_hab2_TextChanged);
            // 
            // tb_grade2
            // 
            this.tb_grade2.Location = new System.Drawing.Point(1024, 210);
            this.tb_grade2.Name = "tb_grade2";
            this.tb_grade2.Size = new System.Drawing.Size(114, 46);
            this.tb_grade2.TabIndex = 8;
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(445, 280);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(303, 68);
            this.btn_save.TabIndex = 9;
            this.btn_save.Text = "성적저장";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // 성적입력
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1193, 360);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.tb_grade2);
            this.Controls.Add(this.tb_grade1);
            this.Controls.Add(this.tb_hab2);
            this.Controls.Add(this.tb_hab);
            this.Controls.Add(this.tb_silgi2);
            this.Controls.Add(this.tb_silgi1);
            this.Controls.Add(this.tb_attend2);
            this.Controls.Add(this.tb_attend1);
            this.Controls.Add(this.tb_final2);
            this.Controls.Add(this.tb_final1);
            this.Controls.Add(this.tb_mid2);
            this.Controls.Add(this.tb_mid1);
            this.Controls.Add(this.tb_name2);
            this.Controls.Add(this.tb_name1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("굴림", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "성적입력";
            this.Text = "성적입력";
            this.Load += new System.EventHandler(this.성적입력_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_name1;
        private System.Windows.Forms.TextBox tb_mid1;
        private System.Windows.Forms.TextBox tb_final1;
        private System.Windows.Forms.TextBox tb_attend1;
        private System.Windows.Forms.TextBox tb_silgi1;
        private System.Windows.Forms.TextBox tb_hab;
        private System.Windows.Forms.TextBox tb_grade1;
        private System.Windows.Forms.TextBox tb_name2;
        private System.Windows.Forms.TextBox tb_mid2;
        private System.Windows.Forms.TextBox tb_final2;
        private System.Windows.Forms.TextBox tb_attend2;
        private System.Windows.Forms.TextBox tb_silgi2;
        private System.Windows.Forms.TextBox tb_hab2;
        private System.Windows.Forms.TextBox tb_grade2;
        private System.Windows.Forms.Button btn_save;
    }
}