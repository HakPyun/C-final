﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class 학생화면 : Form
    {
        string sid;
        public 학생화면(string id)
        {
            InitializeComponent();
            sid = id;
        }

        private void 학생화면_FormClosed(object sender, FormClosedEventArgs e)
        {
            시작화면 시작 = new 시작화면();
            시작.Show();
            this.Hide();
            시작화면.conn.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void 학생화면_Load(object sender, EventArgs e)
        {
            시작화면.디비연결();
            시작화면.sql = "select * from Student " + "where hakbun = '2023123';";
            시작화면.cmd.CommandText = 시작화면.sql;

            SqlDataReader reader = 시작화면.cmd.ExecuteReader();

            if (reader.Read())
            {
                pictureBox1.Image = Image.FromFile(reader.GetString(6));
                tb_name.Text = reader.GetString(1);
                tb_addr.Text = reader.GetString(2);
                tb_phone.Text = reader.GetString(3);
                tb_subject.Text = reader.GetString(4);
                tb_grade.Text = reader.GetDouble(5).ToString();
            }
            reader.Close();
        }

        private void btn_confirm_Click(object sender, EventArgs e)
        {
                성적확인 확인 = new 성적확인(sid);
                확인.Show();
                this.Hide();
        }
    }
}
