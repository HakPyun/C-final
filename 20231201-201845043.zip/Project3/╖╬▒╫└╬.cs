﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class 로그인 : Form
    {
        int gubun;
        public 로그인(int g)
        {
            InitializeComponent();
            gubun = g;
        }

        private void 로그인_Load(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            시작화면.디비연결();
            string id = tb_id.Text;
            string pw = tb_pw.Text;

            if (gubun ==1)
            {
                시작화면.sql = "select * from prof " + " where jikbun ='" + id + "'and pw = '" + pw + "';";
                시작화면.cmd.CommandText = 시작화면.sql;
                SqlDataReader reader = 시작화면.cmd.ExecuteReader();
                if (reader.Read())
                {
                    교수화면 교수 = new 교수화면(id);
                    교수.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("아이디와 비번을 확인");
                    tb_id.Text = "";
                    tb_pw.Text = "";
                    tb_id.Focus();
                }
            }
            else
            {
                시작화면.sql = "select * from student " + " where hakbun = '" + id + "' and pw = '" + pw + "';";
                시작화면.cmd.CommandText = 시작화면.sql;
                SqlDataReader reader = 시작화면.cmd.ExecuteReader();
                if (reader.Read())
                {
                    학생화면 학생 = new 학생화면(id);
                    학생.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("아이디와 비번을 확인");
                    tb_id.Text = "";
                    tb_pw.Text = "";
                    tb_id.Focus();
                }
            }
        }
    }
}
