﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class 교수화면 : Form
    {
        string pid;
        string scode;
        public 교수화면(string id)
        {
            InitializeComponent();
            pid = id;
        }

        private void 교수화면_FormClosed(object sender, FormClosedEventArgs e)
        {
            시작화면 시작 = new 시작화면();
            시작.Show();
            this.Hide();
            시작화면.conn.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void 교수화면_Load(object sender, EventArgs e)
        {
            시작화면.디비연결();
            시작화면.sql = "select * from Prof " + "where jikbun = '"+ pid + "';";
            시작화면.cmd.CommandText = 시작화면.sql;

            SqlDataReader reader = 시작화면.cmd.ExecuteReader();

            if (reader.Read())
            {
                pictureBox1.Image = Image.FromFile(reader.GetString(5));
                tb_name.Text = reader.GetString(1);
                tb_addr.Text = reader.GetString(4);
                tb_phone.Text = reader.GetString(2);
                tb_subject.Text = reader.GetString(3);
            }
            reader.Close();
        }

        private void btn_input_Click(object sender, EventArgs e)
        {
            시작화면.sql = "select * from Prof " + "where jikbun = '" + pid + "';";
            시작화면.cmd.CommandText = 시작화면.sql;

            SqlDataReader reader = 시작화면.cmd.ExecuteReader();
            if (reader.Read())
            {
                scode = reader.GetString(3);
                성적입력 입력 = new 성적입력(scode);
                입력.Show();
                this.Hide();
            }
            
        }
    }
}
