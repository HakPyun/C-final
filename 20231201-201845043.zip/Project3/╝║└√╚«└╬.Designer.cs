﻿namespace Project3
{
    partial class 성적확인
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_grade2 = new System.Windows.Forms.TextBox();
            this.tb_hab2 = new System.Windows.Forms.TextBox();
            this.tb_grade1 = new System.Windows.Forms.TextBox();
            this.tb_silgi2 = new System.Windows.Forms.TextBox();
            this.tb_hab1 = new System.Windows.Forms.TextBox();
            this.tb_attend2 = new System.Windows.Forms.TextBox();
            this.tb_silgi1 = new System.Windows.Forms.TextBox();
            this.tb_final2 = new System.Windows.Forms.TextBox();
            this.tb_attend1 = new System.Windows.Forms.TextBox();
            this.tb_mid2 = new System.Windows.Forms.TextBox();
            this.tb_final1 = new System.Windows.Forms.TextBox();
            this.tb_mid1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_sub2 = new System.Windows.Forms.TextBox();
            this.tb_sub1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tb_grade2
            // 
            this.tb_grade2.Location = new System.Drawing.Point(1062, 289);
            this.tb_grade2.Name = "tb_grade2";
            this.tb_grade2.Size = new System.Drawing.Size(100, 35);
            this.tb_grade2.TabIndex = 26;
            // 
            // tb_hab2
            // 
            this.tb_hab2.Location = new System.Drawing.Point(919, 289);
            this.tb_hab2.Name = "tb_hab2";
            this.tb_hab2.Size = new System.Drawing.Size(100, 35);
            this.tb_hab2.TabIndex = 24;
            // 
            // tb_grade1
            // 
            this.tb_grade1.Location = new System.Drawing.Point(1062, 208);
            this.tb_grade1.Name = "tb_grade1";
            this.tb_grade1.Size = new System.Drawing.Size(100, 35);
            this.tb_grade1.TabIndex = 23;
            // 
            // tb_silgi2
            // 
            this.tb_silgi2.Location = new System.Drawing.Point(795, 289);
            this.tb_silgi2.Name = "tb_silgi2";
            this.tb_silgi2.Size = new System.Drawing.Size(100, 35);
            this.tb_silgi2.TabIndex = 22;
            // 
            // tb_hab1
            // 
            this.tb_hab1.Location = new System.Drawing.Point(919, 208);
            this.tb_hab1.Name = "tb_hab1";
            this.tb_hab1.Size = new System.Drawing.Size(100, 35);
            this.tb_hab1.TabIndex = 21;
            // 
            // tb_attend2
            // 
            this.tb_attend2.Location = new System.Drawing.Point(656, 289);
            this.tb_attend2.Name = "tb_attend2";
            this.tb_attend2.Size = new System.Drawing.Size(100, 35);
            this.tb_attend2.TabIndex = 20;
            // 
            // tb_silgi1
            // 
            this.tb_silgi1.Location = new System.Drawing.Point(795, 208);
            this.tb_silgi1.Name = "tb_silgi1";
            this.tb_silgi1.Size = new System.Drawing.Size(100, 35);
            this.tb_silgi1.TabIndex = 19;
            // 
            // tb_final2
            // 
            this.tb_final2.Location = new System.Drawing.Point(529, 289);
            this.tb_final2.Name = "tb_final2";
            this.tb_final2.Size = new System.Drawing.Size(100, 35);
            this.tb_final2.TabIndex = 25;
            // 
            // tb_attend1
            // 
            this.tb_attend1.Location = new System.Drawing.Point(656, 208);
            this.tb_attend1.Name = "tb_attend1";
            this.tb_attend1.Size = new System.Drawing.Size(100, 35);
            this.tb_attend1.TabIndex = 18;
            // 
            // tb_mid2
            // 
            this.tb_mid2.Location = new System.Drawing.Point(408, 289);
            this.tb_mid2.Name = "tb_mid2";
            this.tb_mid2.Size = new System.Drawing.Size(100, 35);
            this.tb_mid2.TabIndex = 17;
            // 
            // tb_final1
            // 
            this.tb_final1.Location = new System.Drawing.Point(529, 208);
            this.tb_final1.Name = "tb_final1";
            this.tb_final1.Size = new System.Drawing.Size(100, 35);
            this.tb_final1.TabIndex = 16;
            // 
            // tb_mid1
            // 
            this.tb_mid1.Location = new System.Drawing.Point(408, 208);
            this.tb_mid1.Name = "tb_mid1";
            this.tb_mid1.Size = new System.Drawing.Size(100, 35);
            this.tb_mid1.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1076, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 24);
            this.label8.TabIndex = 14;
            this.label8.Text = "학점";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(940, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 24);
            this.label7.TabIndex = 13;
            this.label7.Text = "합계";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(814, 128);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 24);
            this.label6.TabIndex = 12;
            this.label6.Text = "실기";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(675, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 24);
            this.label5.TabIndex = 11;
            this.label5.Text = "출석";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(554, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 24);
            this.label4.TabIndex = 10;
            this.label4.Text = "기말";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(432, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 24);
            this.label3.TabIndex = 9;
            this.label3.Text = "중간";
            // 
            // tb_sub2
            // 
            this.tb_sub2.Location = new System.Drawing.Point(262, 289);
            this.tb_sub2.Name = "tb_sub2";
            this.tb_sub2.Size = new System.Drawing.Size(100, 35);
            this.tb_sub2.TabIndex = 28;
            // 
            // tb_sub1
            // 
            this.tb_sub1.Location = new System.Drawing.Point(262, 208);
            this.tb_sub1.Name = "tb_sub1";
            this.tb_sub1.Size = new System.Drawing.Size(100, 35);
            this.tb_sub1.TabIndex = 27;
            // 
            // 성적확인
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1455, 450);
            this.Controls.Add(this.tb_sub2);
            this.Controls.Add(this.tb_sub1);
            this.Controls.Add(this.tb_grade2);
            this.Controls.Add(this.tb_hab2);
            this.Controls.Add(this.tb_grade1);
            this.Controls.Add(this.tb_silgi2);
            this.Controls.Add(this.tb_hab1);
            this.Controls.Add(this.tb_attend2);
            this.Controls.Add(this.tb_silgi1);
            this.Controls.Add(this.tb_final2);
            this.Controls.Add(this.tb_attend1);
            this.Controls.Add(this.tb_mid2);
            this.Controls.Add(this.tb_final1);
            this.Controls.Add(this.tb_mid1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Name = "성적확인";
            this.Text = "성적확인";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.성적확인_FormClosed);
            this.Load += new System.EventHandler(this.성적확인_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_grade2;
        private System.Windows.Forms.TextBox tb_hab2;
        private System.Windows.Forms.TextBox tb_grade1;
        private System.Windows.Forms.TextBox tb_silgi2;
        private System.Windows.Forms.TextBox tb_hab1;
        private System.Windows.Forms.TextBox tb_attend2;
        private System.Windows.Forms.TextBox tb_silgi1;
        private System.Windows.Forms.TextBox tb_final2;
        private System.Windows.Forms.TextBox tb_attend1;
        private System.Windows.Forms.TextBox tb_mid2;
        private System.Windows.Forms.TextBox tb_final1;
        private System.Windows.Forms.TextBox tb_mid1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_sub2;
        private System.Windows.Forms.TextBox tb_sub1;
    }
}