﻿namespace Project3
{
    partial class 로그인
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_id = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.label_pw = new System.Windows.Forms.Label();
            this.tb_pw = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Location = new System.Drawing.Point(43, 60);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(62, 15);
            this.label_id.TabIndex = 0;
            this.label_id.Text = "아이디 :";
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(293, 60);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(100, 25);
            this.tb_id.TabIndex = 1;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(293, 316);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 2;
            this.btn_login.Text = "로그인";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // label_pw
            // 
            this.label_pw.AutoSize = true;
            this.label_pw.Location = new System.Drawing.Point(46, 103);
            this.label_pw.Name = "label_pw";
            this.label_pw.Size = new System.Drawing.Size(77, 15);
            this.label_pw.TabIndex = 3;
            this.label_pw.Text = "비밀번호 :";
            // 
            // tb_pw
            // 
            this.tb_pw.Location = new System.Drawing.Point(293, 103);
            this.tb_pw.Name = "tb_pw";
            this.tb_pw.Size = new System.Drawing.Size(100, 25);
            this.tb_pw.TabIndex = 4;
            // 
            // 로그인
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb_pw);
            this.Controls.Add(this.label_pw);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.label_id);
            this.Name = "로그인";
            this.Text = "로그인";
            this.Load += new System.EventHandler(this.로그인_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label label_pw;
        private System.Windows.Forms.TextBox tb_pw;
    }
}