﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class 시작화면 : Form
    {
        public 시작화면()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_p_Click(object sender, EventArgs e)
        {
            로그인 login = new 로그인(1);
            login.Show();
            this.Hide();
        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            로그인 login = new 로그인(2);
            login.Show();
            this.Hide();
        }

        public static SqlConnection conn;   //클래스 변수
        public static SqlCommand cmd;       //클래스 변수
        public static string conStr, sql;   //클래스 변수


        public static void 디비연결()
        {
            conStr = "Server=localhost;database=inhaDB;Trusted_Connection=True;";
            conn = new SqlConnection(conStr);
            conn.Open();

            cmd = new SqlCommand();
            cmd.Connection = conn;
        }

        private void 시작화면_Load(object sender, EventArgs e)
        {

        }
    }
}
