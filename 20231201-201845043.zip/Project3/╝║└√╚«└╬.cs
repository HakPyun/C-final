﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class 성적확인 : Form
    {
        String id;
        public 성적확인(string id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void 성적확인_Load(object sender, EventArgs e)
        {
            시작화면.디비연결();
            시작화면.sql = "SELECT * FROM inhasubject WHERE hakbun = '" + id + "';";
            시작화면.cmd.CommandText = 시작화면.sql;
            SqlDataReader reader = 시작화면.cmd.ExecuteReader();
            if (reader.Read())
            {
                tb_sub1.Text = reader.GetString(3);
                tb_mid1.Text = reader.GetInt32(4).ToString();
                tb_final1.Text = reader.GetInt32(5).ToString();
                tb_attend1.Text = reader.GetInt32(6).ToString();
                tb_silgi1.Text = reader.GetInt32(7).ToString();
                tb_hab1.Text = reader.GetInt32(8).ToString();
                tb_grade1.Text = reader.GetDouble(9).ToString();
            }
            if (reader.Read())
            {
                tb_sub2.Text = reader.GetString(3);
                tb_mid2.Text = reader.GetInt32(4).ToString();
                tb_final2.Text = reader.GetInt32(5).ToString();
                tb_attend2.Text = reader.GetInt32(6).ToString();
                tb_silgi2.Text = reader.GetInt32(7).ToString();
                tb_hab2.Text = reader.GetInt32(8).ToString();
                tb_grade2.Text = reader.GetDouble(9).ToString();
            }
            reader.Close();
            
        }

        private void 성적확인_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            시작화면 시작 = new 시작화면();
            시작.Show();
        }
    }
}
