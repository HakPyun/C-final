﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class 성적입력 : Form
    {
        string subcode;
        public 성적입력(string scode)
        {
            InitializeComponent();
            subcode = scode;
        }

        private void 성적입력_Load(object sender, EventArgs e)
        {
            시작화면.디비연결();
            if(subcode == "cse0001") {
            string sqlSubject = "select " +
                "student.sname, " +
                "inhasubject.mid, inhasubject.final, " +
                "inhasubject.attend, inhasubject.silgi " +
                "from inhasubject inner join student " +
                "on inhasubject.hakbun = student.hakbun where scode = 'cse0001';";

            시작화면.cmd.CommandText = sqlSubject;
            SqlDataReader reader = 시작화면.cmd.ExecuteReader();
            if (reader.Read())
            {                
                tb_name1.Text = reader.GetString(0);
                tb_mid1.Text = reader.GetInt32(1).ToString();
                tb_final1.Text = reader.GetInt32(2).ToString();
                tb_attend1.Text = reader.GetInt32(3).ToString();
                tb_silgi1.Text = reader.GetInt32(4).ToString();
            }
            if (reader.Read())
            {
                tb_name2.Text = reader.GetString(0);
                tb_mid2.Text = reader.GetInt32(1).ToString();
                tb_final2.Text = reader.GetInt32(2).ToString();
                tb_attend2.Text = reader.GetInt32(3).ToString();
                tb_silgi2.Text = reader.GetInt32(4).ToString();
            }
            reader.Close();
            tb_mid1.Text = "";
            tb_mid1.Focus();
            }
            else if (subcode == "cse0002")
            {
                label1.Text = "파이썬";
                string sqlSubject = "select " +
                "student.sname, " +
                "inhasubject.mid, inhasubject.final, " +
                "inhasubject.attend, inhasubject.silgi " +
                "from inhasubject inner join student " +
                "on inhasubject.hakbun = student.hakbun where scode = 'cse0002';";

                시작화면.cmd.CommandText = sqlSubject;
                SqlDataReader reader = 시작화면.cmd.ExecuteReader();
                if (reader.Read())
                {
                    tb_name1.Text = reader.GetString(0);
                    tb_mid1.Text = reader.GetInt32(1).ToString();
                    tb_final1.Text = reader.GetInt32(2).ToString();
                    tb_attend1.Text = reader.GetInt32(3).ToString();
                    tb_silgi1.Text = reader.GetInt32(4).ToString();
                }
                if (reader.Read())
                {
                    tb_name2.Text = reader.GetString(0);
                    tb_mid2.Text = reader.GetInt32(1).ToString();
                    tb_final2.Text = reader.GetInt32(2).ToString();
                    tb_attend2.Text = reader.GetInt32(3).ToString();
                    tb_silgi2.Text = reader.GetInt32(4).ToString();
                }
                reader.Close();
                tb_mid1.Text = "";
                tb_mid1.Focus();
            }
        }

        private void tb_final1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_final1_Click(object sender, EventArgs e)
        {
            tb_final1.Text = "";
        }

        private void tb_attend1_Click(object sender, EventArgs e)
        {
            tb_attend1.Text = "";
        }

        private void tb_silgi1_Click(object sender, EventArgs e)
        {
            tb_silgi1.Text = "";
        }
        float hakjum;
        float hakjum2;
        private void tb_hab_Click(object sender, EventArgs e)
        {
            int mid, final, attend, silgi;            
            mid = int.Parse(tb_mid1.Text);
            final = int.Parse(tb_final1.Text);
            attend = int.Parse(tb_attend1.Text);
            silgi = int.Parse(tb_silgi1.Text);
            int hab = mid + final + attend + silgi;
            tb_hab.Text = hab.ToString();

            if (hab >= 95 && hab <= 100)
            {
                tb_grade1.Text = "A+";
                hakjum = 4.5f;
            }
            else if(hab >= 90 && hab < 95)
            {
                tb_grade1.Text = "A0";
                hakjum = 4.0f;
            }
            else if (hab >= 85 && hab < 90)
            {
                tb_grade1.Text = "B+";
                hakjum = 3.5f;
            }
            else if (hab >= 80 && hab < 85)
            {
                tb_grade1.Text = "B0";
                hakjum = 3.0f;
            }
            else if (hab >= 75 && hab < 80)
            {
                tb_grade1.Text = "C+";
                hakjum = 2.5f;
            }
            else if (hab >= 70 && hab < 75)
            {
                tb_grade1.Text = "C0";
                hakjum = 2.0f;
            }
            else if (hab >= 65 && hab < 70)
            {
                tb_grade1.Text = "D+";
                hakjum = 1.5f;
            }
            else if (hab >= 60 && hab < 65)
            {
                tb_grade1.Text = "D0";
                hakjum = 1.0f;
            }
            else
            {
                tb_grade1.Text = "F";
                hakjum = 0.0f;
            }
        }

        private void tb_hab2_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_hab2_Click(object sender, EventArgs e)
        {
            int mid, final, attend, silgi;
            
            mid = int.Parse(tb_mid2.Text);
            final = int.Parse(tb_final2.Text);
            attend = int.Parse(tb_attend2.Text);
            silgi = int.Parse(tb_silgi2.Text);
            int hab = mid + final + attend + silgi;
            tb_hab2.Text = hab.ToString();

            if (hab >= 95 && hab <= 100)
            {
                tb_grade2.Text = "A+";
                hakjum2 = 4.5f;
            }
            else if (hab >= 90 && hab < 95)
            {
                tb_grade2.Text = "A0";
                hakjum2 = 4.0f;
            }
            else if (hab >= 85 && hab < 90)
            {
                tb_grade2.Text = "B+";
                hakjum2 = 3.5f;
            }
            else if (hab >= 80 && hab < 85)
            {
                tb_grade2.Text = "B0";
                hakjum2 = 3.0f;
            }
            else if (hab >= 75 && hab < 80)
            {
                tb_grade2.Text = "C+";
                hakjum2 = 2.5f;
            }
            else if (hab >= 70 && hab < 75)
            {
                tb_grade2.Text = "C0";
                hakjum2 = 2.0f;
            }
            else if (hab >= 65 && hab < 70)
            {
                tb_grade2.Text = "D+";
                hakjum2 = 1.5f;
            }
            else if (hab >= 60 && hab < 65)
            {
                tb_grade2.Text = "D0";
                hakjum2 = 1.0f;
            }
            else
            {
                tb_grade2.Text = "F";
                hakjum2 = 0.0f;
            }

        }

        private void tb_hab_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            시작화면.디비연결();
            int mid, final, attend, silgi, hab;
            mid = int.Parse(tb_mid1.Text);
            final = int.Parse(tb_final1.Text);
            attend = int.Parse(tb_attend1.Text);
            silgi = int.Parse(tb_silgi1.Text);
            hab = mid + final + attend + silgi;
            시작화면.sql = "update inhasubject set mid = " + mid + " , " +
                "final = " + final + " , attend = " + attend + " , " +
                "silgi = " + silgi + " , hab = " + hab + ", " +
                "grade = " + hakjum + " where hakbun = '2023123' and scode = '"+ subcode + "';";

            시작화면.cmd.CommandText = 시작화면.sql;
            시작화면.cmd.ExecuteNonQuery();

            mid = int.Parse(tb_mid2.Text);
            final = int.Parse(tb_final2.Text);
            attend = int.Parse(tb_attend2.Text);
            silgi = int.Parse(tb_silgi2.Text);
            hab = mid + final + attend + silgi;

            시작화면.sql = "update inhasubject set mid = " + mid + " , " +
                "final = " + final + " , attend = " + attend + " , " +
                "silgi = " + silgi + " , hab = " + hab + ", " +
                "grade = " + hakjum2 + " where hakbun = '2023124' and scode = '" + subcode + "';";

            시작화면.cmd.CommandText = 시작화면.sql;
            시작화면.cmd.ExecuteNonQuery();


            MessageBox.Show("성적 저장이 완료되었습니다.");
            시작화면.conn.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
